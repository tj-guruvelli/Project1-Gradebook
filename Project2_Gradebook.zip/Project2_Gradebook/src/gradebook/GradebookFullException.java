/*
 * Assignment Name: Project 2
 * @author Teja Guruvelli
 */

package gradebook;


@SuppressWarnings("serial")
public class GradebookFullException extends Exception{

	public GradebookFullException() {
	}

	public GradebookFullException(String message) {
		super(message);
	}

}
