/*
 * Assignment Name: Project 2
 * @author Teja Guruvelli
 */

package gradebook;

import java.util.ArrayList;
import java.util.Objects;

public class Program implements AssignmentInterface{
	
	// Variables
	private String conceptType;
	
	private int score;
	private String name;
	private String letter;
	private String dueDate;
			
	// Constructors
	public Program()
	{
		conceptType = "";
		score = 0;
		letter = "";
		name = "";
	}
			
	public Program(String conceptType, int score, String letter, String name, String dueDate)
	{
		this.conceptType = conceptType;
		this.score = score;
		this.letter = letter;
		this.name = name;
		this.dueDate = dueDate;
	}
	
	// Methods
	public String getConceptType() {return conceptType;}
	public void setConceptType(String conceptType) {this.conceptType = conceptType;}
	
	public void printProgramConcepts(ArrayList<AssignmentInterface> array)
	{
		System.out.println("Content of Program Concepts: ");
		System.out.println("*******************************");
		String typeCon;
		for (int i = 0; i < array.size(); i++) {
			if (array.get(i) instanceof Program) {
				typeCon = ((Program) array.get(i)).getConceptType();
			System.out.println(typeCon);
			}
		}
		System.out.println();
	}


	public int getScore() {return score;}
	public void setScore(int tempScore) {score = tempScore;}
	public String getLetter() {return letter;}
	public void setLetter(String c) {letter = c;}
	public String getName() {return name;}
	public void setName(String s) {name = s;}
	public String getDueDate() {return dueDate;}
	public void setDueDate(String t) {dueDate = t;}
	public String toString()
	{
		//"Name: " + Quiz1, Score: 90, Letter: A, Due: 09/15/21 ...�
		return ("Concept Type: " + getConceptType() + ", " +
						   "Name: " + getName() + ", " +
						   "Score: " + getScore() + ", " +
						   "Letter: " + getLetter() + ", " +
						   "Due Date: " + getDueDate());
		
	}

	@Override
	public int hashCode() {
		return Objects.hash(conceptType, dueDate, letter, name, score);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Program other = (Program) obj;
		return Objects.equals(conceptType, other.conceptType) && Objects.equals(dueDate, other.dueDate)
				&& Objects.equals(letter, other.letter) && Objects.equals(name, other.name) && score == other.score;
	}
	
	

}
