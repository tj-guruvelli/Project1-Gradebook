/*
 * Assignment Name: Project 2
 * @author Teja Guruvelli
 */

package gradebook;

public interface AssignmentInterface {

		 int getScore();
		 void setScore(int tempScore);

		 String getLetter();
		 void setLetter(String c);

		 String getName();
		 void setName(String s);

		 String getDueDate();
		 void setDueDate(String t);
		
		String toString();

}

