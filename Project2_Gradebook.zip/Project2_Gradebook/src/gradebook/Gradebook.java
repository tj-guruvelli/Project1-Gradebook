/*
 * Assignment Name: Project 2
 * @author Teja Guruvelli
 */

package gradebook;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Gradebook implements AssignmentInterface {

	// Variables
	public static String conceptType;
	public static String correspondReading;
	public static int numQuestions;

	public static int score;
	public static String name;
	public static String letter;
	public static String dueDate;

	public static int pObjs;
	public static int dObjs;
	public static int qObjs;

	public static int counter;

	public static void main(String[] args) throws SQLException {

		// Variable
		int gradeBookSize = 0;

		// display a welcome message
		System.out.println("Welcome to the Gradebook Manager\n");

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number of students to store (20 max students): ");
		boolean checkInput = false;
		while (!checkInput || gradeBookSize < 0 || gradeBookSize > 20) {
			try {
				// Takes in the user input for number of students to store
				gradeBookSize = Integer.valueOf(sc.nextLine());
				if (gradeBookSize > 20 || gradeBookSize < 0) {
					System.out.println("Invalid Input! Enter a range between(0-20) ");
					continue;
				}
				checkInput = true;
			} catch (NumberFormatException e) {
				System.out.println("Invalid Input! Enter a range between(0-20) ");
			}
		}

		// Creating and allocating space for an array with the number of students
		// specified
		ArrayList<AssignmentInterface> studentArray = new ArrayList<AssignmentInterface>(gradeBookSize);

		// perform 1 or more actions
		int option = 0;

		while (option != 9) {
			// get the input from the user
			// display the command menu
			displayMenu();
			System.out.println("Enter option (number): ");
			// Checks for Invalid Input
			checkInput = false;
			while (!checkInput || option < 0 || option > 9) {
				try {
					// Takes in the user input for number of students to store
					option = Integer.parseInt(sc.nextLine());
					if (option > 9 || option < 0) {
						System.out.println("Invalid Input! Enter a range between(1-9) ");
						continue;
					}
					checkInput = true;
				} catch (NumberFormatException e) {
					System.out.println("Invalid Input! Enter a range between(1-9) ");
				}
			}

			switch (option) {
			case 1:
				// GradebookFullException
				try {
					if (counter == gradeBookSize) {
						throw new GradebookFullException();
					}
				} catch (GradebookFullException e) {
					System.out.println("The Gradebook is Full\n");
					break;
				}
				studentArray = addGrades(studentArray);
				counter++;
				break;
			case 2:
				// GradebookEmptyException
				try {
					if (counter == 0) {
						throw new GradebookEmptyException();
					}
				} catch (GradebookEmptyException e) {
					System.out.println("The Gradebook is Empty\n");
					break;
				}
				
				// Print out the contents of the list
				String contents;
				System.out.println("Current Grades in the Gradebook");
				System.out.println("*******************************");
				for (int i = 0; i < studentArray.size(); i++) {
					contents = studentArray.get(i).toString();
					System.out.println(contents);
				}
				
				System.out.println("Enter name to remove: ");
				String removeGradeName = sc.nextLine();

				studentArray = removeGrade(studentArray, removeGradeName);
				
				break;
			case 3:
				printGrades(studentArray);
				break;
			case 4:
				try {
					printToFile(studentArray);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 5:
				System.out.println("Enter file name to open: ");
				String filename = sc.nextLine();
				try {
					studentArray = readFromFile(filename);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 6:
				// Insert into the table
				for (int i = 0; i < studentArray.size(); i++) {
					String query = "INSERT INTO Gradebook (AssignmentType, Name, Score, Letter, Due_Date, Unique_Var) "
							+ "VALUES (?, ?, ?, ?, ?, ?) ";
					Connection connection = DBUtil2.getConnection();
					// Creating a table if it doesn't exist
					String tableCreate = "CREATE TABLE IF NOT EXISTS " + "Gradebook"
					+ "(ID    			INT            PRIMARY KEY  AUTO_INCREMENT,"
					+ "AssignmentType 	VARCHAR(100),"
					+ "Name 			VARCHAR(100),"
					+ "Score 			INT,"
					+ "Letter 			VARCHAR(100),"
					+ "Due_Date 		VARCHAR(100),"
					+ "Unique_Var		VARCHAR(100))";
					
					Statement createTable = connection.createStatement();
					createTable.execute(tableCreate);
					
					try (PreparedStatement ps = connection.prepareStatement(query)) {

						ps.setString(2, studentArray.get(i).getName());
						ps.setInt(3, studentArray.get(i).getScore());
						ps.setString(4, studentArray.get(i).getLetter());
						ps.setString(5, studentArray.get(i).getDueDate());
						if (studentArray.get(i) instanceof Discussion) {
							Discussion d = (Discussion) studentArray.get(i);
							ps.setString(1, "Discussion");
							ps.setString(6, d.getCorrespondReading());
						}
						if (studentArray.get(i) instanceof Quiz) {
							Quiz q = (Quiz) studentArray.get(i);
							ps.setString(1, "Quiz");
							ps.setString(6, String.valueOf(q.getNumQuestions()));
						}
						if (studentArray.get(i) instanceof Program) {
							Program p = (Program) studentArray.get(i);
							ps.setString(1, "Program");
							ps.setString(6, p.getConceptType());
						}

						ps.executeUpdate();

					} catch (SQLException e) {
						System.out.println(e);

					}
				}
				System.out.println();
				System.out.println("Data loaded into Database\n");
				break;
			case 7:
				// Checks if there are any unadded grades
				// For the unadded grade book SQL query to return the grades
				// Parse the grades and information into the arraylist GradeBook
				Connection connection = DBUtil2.getConnection();

				String query = "SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook";
				ArrayList<AssignmentInterface> gradeBookDBList = readFromDBAsList(connection, query);

				for (AssignmentInterface fileObj : gradeBookDBList) {
					if (!studentArray.contains(fileObj)) {
						//System.out.println("Not found : " + fileObj.toString());
						studentArray.add(fileObj);
					}
				}
				System.out.println();
				System.out.println("Data loaded into local Gradebook\n");
				break;
			case 8:
				SQLSearch(studentArray);
				break;
			}
		}

		DBUtil2.closeConnection();
		quit();
		sc.close();
	}

	// Reads and uses query language to add to the local gradebook from the Database
	private static ArrayList<AssignmentInterface> readFromDBAsList(Connection connection, String query) {
		ArrayList<AssignmentInterface> gradeBookDBList = new ArrayList<AssignmentInterface>();

		try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				String assignmentName = rs.getString("assignmentType");
				String nameDB = rs.getString("name");
				int scoreDB = rs.getInt("score");
				String letterDB = rs.getString("letter");
				String dueDateDB = rs.getString("due_date");
				String unqiueVarDB = rs.getString("Unique_Var");
				if (assignmentName.equalsIgnoreCase("Quiz")) {

					gradeBookDBList.add(new Quiz(Integer.parseInt(unqiueVarDB), scoreDB, letterDB, nameDB, dueDateDB));
				}
				if (assignmentName.equalsIgnoreCase("Program")) {

					gradeBookDBList.add(new Program(unqiueVarDB, scoreDB, letterDB, nameDB, dueDateDB));
				}
				if (assignmentName.equalsIgnoreCase("Discussion")) {

					gradeBookDBList.add(new Discussion(unqiueVarDB, scoreDB, letterDB, nameDB, dueDateDB));
				}

			}
			rs.close();

		} catch (SQLException e) {
			System.out.println(e);
		}
		return gradeBookDBList;
	}

	public static void displayMenu() {

		System.out.println();
		System.out.println("GRADEBOOK MENU");
		System.out.println("1) Add Grade");
		System.out.println("2) Remove Grade");
		System.out.println("3) Print Grades");
		System.out.println("4) Print to File");
		System.out.println("5) Read from File");
		System.out.println("6) To MySQL");
		System.out.println("7) From MySQL");
		System.out.println("8) MySQL Search");
		System.out.println("9) Quit\n");

	}

	public static ArrayList<AssignmentInterface> addGrades(ArrayList<AssignmentInterface> studentArray) {
		Scanner sc = new Scanner(System.in);
		int objectType = 0;
		int numofQuestions;
		int tempScore = 0;

		// get the input from the user about the type of assignment
		// Checks for Invalid Input
		boolean checkInput = false;
		while (!checkInput || objectType > 3 || objectType < 1) {
			try {
				System.out.println("1) Quiz");
				System.out.println("2) Program");
				System.out.println("3) Discussion");
				System.out.println("Choose the assignment (number) to add: ");
				objectType = Integer.parseInt(sc.nextLine());
				if (objectType > 3 || objectType < 1) {
					System.out.println("Invalid Input! Enter a range between (1-3) ");
					continue;
				}
				checkInput = true;
			} catch (NumberFormatException e) {
				System.out.println("Invalid Input! Enter a range between(1-3) ");
			}
		}

		// Assignment name
		System.out.println("Enter assignment name: ");
		String nameStr = sc.nextLine();

		checkInput = false;
		// storing Score from user
		System.out.println("Enter score: ");
		while (!checkInput) {
			try {
				tempScore = Integer.valueOf(sc.nextLine());
				checkInput = true;
			} catch (NumberFormatException e) {
				System.out.println("Invalid Input! Enter a range between(0-100) ");
			}
		}

		String tempGrade;
		// calculates Letter Grade
		if (tempScore >= 90) {
			tempGrade = "A";
		} else if (tempScore >= 80) {
			tempGrade = "B";
		} else if (tempScore >= 70) {
			tempGrade = "C";
		} else if (tempScore >= 60) {
			tempGrade = "D";
		} else {
			tempGrade = "F";
		}

		// Storing the due date from the user
		System.out.println("Enter the due date for the assignment (yyyy-mm-dd): ");
		String dateDue = sc.nextLine();

		switch (objectType) {
		case 1:
			System.out.println("How many questions are on the quiz: ");
			// Checks for Invalid Input
			checkInput = false;
			while (!checkInput) {
				try {
					numofQuestions = Integer.parseInt(sc.nextLine());
					checkInput = true;
					studentArray.add(new Quiz(numofQuestions, tempScore, tempGrade, nameStr, dateDue));
				} catch (NumberFormatException e) {
					System.out.println("Invalid Input! Enter an integer:  ");
				}
			}

			qObjs++;
			break;
		case 2:
			System.out.println("What is the program testing: ");
			String tempconceptType = sc.nextLine();

			studentArray.add(new Program(tempconceptType, tempScore, tempGrade, nameStr, dateDue));
			pObjs++;
			break;
		case 3:
			System.out.println("What is the associated reading?");
			String tempReading = sc.nextLine();

			studentArray.add(new Discussion(tempReading, tempScore, tempGrade, nameStr, dateDue));
			dObjs++;
			break;
		}

		return studentArray;
	}

	public static ArrayList<AssignmentInterface> removeGrade(ArrayList<AssignmentInterface> studentArray,
			String removeGradeName) {

		boolean ifFound = false;
		boolean checkInput = false;
		while (!checkInput) {
			try {

				for (int i = 0; i < studentArray.size(); i++) {
					if (studentArray.get(i).getName().equalsIgnoreCase(removeGradeName)) {
						checkInput = true;
					}
				}
				if (checkInput == false) {
					// Invalid Grade Exception
					throw new InvalidGradeException();
				}

				for (int i = 0; i < studentArray.size(); i++) {
					if (studentArray.get(i).getName().equalsIgnoreCase(removeGradeName)) {
						ifFound = true;

						if (studentArray.get(i) instanceof Quiz) {
							qObjs--;
						}
						if (studentArray.get(i) instanceof Discussion) {
							dObjs--;
						}
						if (studentArray.get(i) instanceof Program) {
							pObjs--;
						}
						studentArray.remove(i);
						counter--; // Decreases count in gradebook
					}
				}
			} catch (InvalidGradeException e) {
				System.out.println("The grade does not exist in the gradebook\n");
				return studentArray;
			}
			if (ifFound == true) {
				System.out.println("Grade was sucessfully removed\n");
			}
			if (ifFound == false) {
				System.out.println("The name does not exist");
			}

		}
		return studentArray;

	}

	public static void printGrades(ArrayList<AssignmentInterface> studentArray) {
		// get the input from the user about the type of assignment
		Scanner sc = new Scanner(System.in);
		// Checks for Invalid Input
		boolean checkInput = false;
		int sortType = 0;
		while (!checkInput || sortType > 4 || sortType < 1) {
			try {
				System.out.println("1) Score (numeric)");
				System.out.println("2) Letter");
				System.out.println("3) Alphabetical Name");
				System.out.println("4) Due Date");
				System.out.println("Choose the sort type (number) to add: ");
				sortType = Integer.parseInt(sc.nextLine());
				if (sortType > 4 || sortType < 1) {
					System.out.println("Invalid Input! Enter a range between (1-4) ");
					continue;
				}
				checkInput = true;
			} catch (NumberFormatException e) {
				System.out.println("Invalid Input! Enter a range between(1-4) ");
			}
		}

		switch (sortType) {
		case 1:
			System.out.println("Current Grades in the Gradebook by Score");
			System.out.println("*******************************");
			Collections.sort(studentArray, new Comparator<AssignmentInterface>() {
				public int compare(AssignmentInterface s1, AssignmentInterface s2) {
					return s1.getScore() - s2.getScore();
				}
			});
			for (int i = 0; i < studentArray.size(); i++) {
				String printedScore = studentArray.get(i).toString();
				System.out.println(printedScore);
			}

			break;
		case 2:
			System.out.println("Current Grades in the Gradebook by Letter");
			System.out.println("*******************************");
			Collections.sort(studentArray, new Comparator<AssignmentInterface>() {
				public int compare(AssignmentInterface s1, AssignmentInterface s2) {
					return s1.getLetter().compareTo(s2.getLetter());
				}
			});
			for (int i = 0; i < studentArray.size(); i++) {
				String printedScore = studentArray.get(i).toString();
				System.out.println(printedScore);
			}
			break;
		case 3:
			System.out.println("Current Grades in the Gradebook by Alphabetical name");
			System.out.println("*******************************");
			Collections.sort(studentArray, new Comparator<AssignmentInterface>() {
				public int compare(AssignmentInterface s1, AssignmentInterface s2) {
					return s1.getName().compareTo(s2.getName());
				}
			});
			for (int i = 0; i < studentArray.size(); i++) {
				String printedScore = studentArray.get(i).toString();
				System.out.println(printedScore);
			}
			break;
		case 4:
			System.out.println("Current Grades in the Gradebook by Due Date");
			System.out.println("*******************************");
			Collections.sort(studentArray, new Comparator<AssignmentInterface>() {
				public int compare(AssignmentInterface s1, AssignmentInterface s2) {

					return LocalDate.parse(s1.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE)
							.compareTo(LocalDate.parse(s2.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE));
				}
			});
			for (int i = 0; i < studentArray.size(); i++) {
				String printedScore = studentArray.get(i).toString();
				System.out.println(printedScore);
			}
			break;
		}

	}

	public static void printToFile(ArrayList<AssignmentInterface> studentArray) throws IOException {

		// Get path to source directory
		Path currentDir = Paths.get("GradeTextFiles");
		// System.out.println(currentDir.toAbsolutePath());

//		File file = new File(".");
//		for(String fileNames : file.list()) System.out.println(fileNames);

		Quiz q = new Quiz();
		Discussion d = new Discussion();
		Program p = new Program();

		// Asks user for filename to edit
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a name for the file: ");
		String fileString = sc.nextLine();
		// String fileString = "products.txt";
		Path gradebookPath = Paths.get(currentDir.toString(), fileString);
		File gradebookFile = gradebookPath.toFile();

//		if (Files.notExists(filePath)) {
//			Files.createFile(filePath);
//		}
//
//		System.out.println("File name:      " + filePath.getFileName());
//		System.out.println("Absolute path:  " + filePath.toAbsolutePath());
//		System.out.println("Is writable:    " + Files.isWritable(filePath));

		// Writing data to a external file
		try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(gradebookFile)))) {
			for (int i = 0; i < studentArray.size(); i++) {
				if (studentArray.get(i) instanceof Quiz) {
					q = (Quiz) studentArray.get(i);

					out.println("Quiz" + "\t" + studentArray.get(i).getName() + "\t" + studentArray.get(i).getScore()
							+ "\t" + studentArray.get(i).getLetter() + "\t" + studentArray.get(i).getDueDate() + "\t"
							+ q.getNumQuestions());
				}
				if (studentArray.get(i) instanceof Discussion) {
					d = (Discussion) studentArray.get(i);
					out.println("Discussion" + "\t" + studentArray.get(i).getName() + "\t"
							+ studentArray.get(i).getScore() + "\t" + studentArray.get(i).getLetter() + "\t"
							+ studentArray.get(i).getDueDate() + "\t" + d.getCorrespondReading());
				}
				if (studentArray.get(i) instanceof Program) {
					p = (Program) studentArray.get(i);
					out.println("Program" + "\t" + studentArray.get(i).getName() + "\t" + studentArray.get(i).getScore()
							+ "\t" + studentArray.get(i).getLetter() + "\t" + studentArray.get(i).getDueDate() + "\t"
							+ p.getConceptType());
				}
			}
			out.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		System.out.println("Data has been written to the file");
	}

	// Reading data from a file
	public static ArrayList<AssignmentInterface> readFromFile(String fileString) throws IOException {
		// Get path to source directory
		Path currentDir = Paths.get("GradeTextFiles");
		ArrayList<AssignmentInterface> studentArray = new ArrayList<AssignmentInterface>();
//		File file = new File(".");
//		for (String fileNames : file.list())
//			System.out.println(fileNames);

		// Retrieves the path of the source folder to find the specified file
		Path gradebookPath = Paths.get(currentDir.toString(), fileString);
		File gradebookFile = gradebookPath.toFile();
		// System.out.println(gradebookPath.toAbsolutePath());

		if (Files.notExists(gradebookPath)) {
			System.out.println("The file does not exist");
		} else {
			// Parsing data from a file into the local gradebook
			try (BufferedReader in = new BufferedReader(new FileReader(gradebookFile))) {
				String line = null;
				while ((line = in.readLine()) != null) {
					// Parse the line into its columns
					String[] columns = line.split("\t");
					String assignmentType = columns[0];
					String name = columns[1];
					int score = Integer.parseInt(columns[2]);
					String letter = columns[3];
					String dueDate = columns[4];
					String unique = columns[5];

					// Create grade
					// Adding Grades to the gradebook
					if (assignmentType.equalsIgnoreCase("Quiz")) {
						studentArray.add(new Quiz(Integer.parseInt(unique), score, letter, name, dueDate));
						qObjs++;
					}
					if (assignmentType.equalsIgnoreCase("Program")) {

						studentArray.add(new Program(unique, score, letter, name, dueDate));
						pObjs++;
					}
					if (assignmentType.equalsIgnoreCase("Discussion")) {

						studentArray.add(new Discussion(unique, score, letter, name, dueDate));
						dObjs++;
					}
					counter++;
				}
			} catch (IOException e) {
				System.out.println(e);
			}
			System.out.println("Data has been read from the file");

		}
		return studentArray;
	}

	// Search and restrict results by queries
	public static void SQLSearch(ArrayList<AssignmentInterface> studentArray) {

		// get the input from the user about the type of assignment
		Scanner sc = new Scanner(System.in);
		// Checks for Invalid Input
		boolean checkInput = false;
		int searchType = 0;
		while (!checkInput || searchType > 6 || searchType < 1) {
			try {
				System.out.println("1) All quizzes");
				System.out.println("2) All programs");
				System.out.println("3) All discussions");
				System.out.println("4) All grades within a certain score range");
				System.out.println("5) All grades within a certain due date range");
				System.out.println("6) All grades with an even score");
				System.out.println("Choose the search query type (number) to search: ");
				searchType = Integer.parseInt(sc.nextLine());
				if (searchType > 6 || searchType < 1) {
					System.out.println("Invalid Input! Enter a range between (1-6) ");
					continue;
				}
				checkInput = true;
			} catch (NumberFormatException e) {
				System.out.println("Invalid Input! Enter a range between(1-6) ");
			}
		}

		// Get connection with database
		Connection connection = DBUtil2.getConnection();
		switch (searchType) {
		case 1:
			String query = "SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where assignmentType = 'Quiz' ";
			ArrayList<AssignmentInterface> quizList = readFromDBAsList(connection, query);
			for (int i = 0; i < quizList.size(); i++) {
				String printContent = quizList.get(i).toString();
				System.out.println(printContent);
			}
			break;
		case 2:
			String query2 = "SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where assignmentType = 'Program' ";
			ArrayList<AssignmentInterface> programList = readFromDBAsList(connection, query2);
			for (int i = 0; i < programList.size(); i++) {
				String printContent = programList.get(i).toString();
				System.out.println(printContent);
			}
			break;
		case 3:
			String query3 = "SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where assignmentType = 'Discussion' ";
			ArrayList<AssignmentInterface> discussionList = readFromDBAsList(connection, query3);
			for (int i = 0; i < discussionList.size(); i++) {
				String printContent = discussionList.get(i).toString();
				System.out.println(printContent);
			}
			break;
		case 4:
			checkInput = false;
			int scoreUpper = 0;
			int scoreLower = 0;
			// storing Score from user

			while (!checkInput || scoreUpper > 100 && scoreUpper < 0 || scoreLower > 100 && scoreLower < 0) {
				try {
					System.out.println("Enter lower score range: ");
					scoreLower = Integer.valueOf(sc.nextLine());
					System.out.println("Enter upper score range: ");
					scoreUpper = Integer.valueOf(sc.nextLine());

					if (scoreUpper > 100 && scoreUpper < 0 || scoreLower > 100 && scoreLower < 0) {
						System.out.println("Invalid Input! Enter a range between (0-100) ");
						continue;
					}
					checkInput = true;
				} catch (NumberFormatException e) {
					System.out.println("Invalid Input! Enter a range between(0-100) ");
				}
			}

			String scoreQuery = String.format(
					"SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where score > %s and score < %s ",
					scoreLower, scoreUpper);
			ArrayList<AssignmentInterface> scorerangeList = readFromDBAsList(connection, scoreQuery);
			for (int i = 0; i < scorerangeList.size(); i++) {
				String printContent = scorerangeList.get(i).toString();
				System.out.println(printContent);
			}
			break;
		case 5:
			String dateUpper;
			String dateLower;
			// storing Score from user
			System.out.println("Enter lower date range (yyyy-mm-dd): ");
			dateLower = sc.nextLine();
			System.out.println("Enter upper date range (yyyy-mm-dd): ");
			dateUpper = sc.nextLine();

			String dateRangeQuery = String.format(
					"SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where Date(due_date) BETWEEN  CAST('%s' as Date) and CAST('%s' as Date) order by Date(due_date)",
					dateLower, dateUpper);
			
			ArrayList<AssignmentInterface> dateRangeList = readFromDBAsList(connection, dateRangeQuery);
			for (int i = 0; i < dateRangeList.size(); i++) {
				String printContent = dateRangeList.get(i).toString();
				System.out.println(printContent);
			}

			break;
		case 6:
			String scoreEvenQuery = String.format(
					"SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook WHERE mod(score, 2) = 0; ");
			ArrayList<AssignmentInterface> evenScoreList = readFromDBAsList(connection, scoreEvenQuery);
			for (int i = 0; i < evenScoreList.size(); i++) {
				String printContent = evenScoreList.get(i).toString();
				System.out.println(printContent);
			}
			break;

		}
		DBUtil2.closeConnection();

	}

	public static void quit() {
		System.out.println("Bye.\n");
		System.exit(0);
	}

	public int getScore() {
		return score;
	}

	public void setScore(int tempScore) {
		score = tempScore;
	}

	public String getLetter() {
		return letter;
	}

	public void setLetter(String tempLetter) {
		letter = tempLetter;
	}

	public String getName() {
		return name;
	}

	public void setName(String s) {
		name = s;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String t) {
		dueDate = t;
	}

}
