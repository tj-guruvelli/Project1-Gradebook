package gradebook;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class JunitTesting {

	public static String conceptType;
	public static String correspondReading;
	public static int numQuestions;

	public static int score;
	public static String name;
	public static String letter;
	public static String dueDate;
	
	private static final int DEFAULT_TIMEOUT = 3000;
	
	private String fileName = "answer2";
	
	
	ArrayList<AssignmentInterface> testList = new ArrayList<AssignmentInterface>();
	@Test(timeout = DEFAULT_TIMEOUT)
	public void readFromFile() throws IOException {
		// Testing reading grades for all three types of assignments
		// Ensure the values are correct
		//		Quiz	quiz2	86	B	2021-11-23	65
		//		Program	web1	94	A	2021-12-01	jaa
		
		Gradebook gb = new Gradebook();
		ArrayList<AssignmentInterface> gradesList = gb.readFromFile(fileName);
		System.out.println(gradesList.toString());
		assertEquals(2, gradesList.size());
		assertEquals("quiz2", gradesList.get(0).getName());
		assertEquals("web1", gradesList.get(1).getName());
		
	}
	
	@Test(timeout = DEFAULT_TIMEOUT)
	public void removeGradeTest() throws IOException {
		// Test removing grades for all three types of assignments
		// Ensure the values are correct
		//		Quiz	quiz2	86	B	2021-11-23	65
		//		Program	web1	94	A	2021-12-01	jaa
		
		Gradebook gb = new Gradebook();
		ArrayList<AssignmentInterface> gradesList = gb.readFromFile(fileName);
		System.out.println(gradesList.toString());
		assertEquals(2, gradesList.size());
		assertEquals("quiz2", gradesList.get(0).getName());
		assertEquals("web1", gradesList.get(1).getName());
		
		
		gb.removeGrade(gradesList,  "web1");
		assertEquals(1, gradesList.size());
		assertEquals("quiz2", gradesList.get(0).getName());
		
		
	}
	
	
	
}
