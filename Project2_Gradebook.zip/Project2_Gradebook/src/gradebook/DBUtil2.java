package gradebook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class DBUtil2 {
    
    private static Connection connection;
    
    private DBUtil2() {}

    public static synchronized Connection getConnection() {
        if (connection != null) {
            return connection;
        }
        else {
            try {
                // set the db url, username, and password
                String url = "jdbc:mysql://database-1.myawsdb.cno2zewghfii.us-east-1.rds.amazonaws.com:3306/Projects_Schema";
                Scanner sc  = new Scanner(System.in);
                System.out.println("Enter username: ");
                String username = sc.nextLine();
                //"admin";\
                System.out.println("Enter password: ");
                String password = sc.nextLine();
                //"#Clemson2024";

                // get and return connection
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                
                connection = DriverManager.getConnection(
                        url, username, password);
                System.out.println("Got connection!");
                System.out.println();
                return connection;
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }            
        }
		return connection;
    }
    
    public static synchronized void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connection = null;                
            }
        }
    }
}