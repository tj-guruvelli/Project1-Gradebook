/*
 * Assignment Name: Project 2
 * @author Teja Guruvelli
 */

package gradebook;

@SuppressWarnings("serial")
public class InvalidGradeException extends Exception{

	public InvalidGradeException() {
	}

	public InvalidGradeException(String message) {
		super(message);
	}

}
