USE Projects_Schema;
DROP TABLE IF EXISTS Gradebook;

CREATE TABLE Gradebook
(
  ID    INT            PRIMARY KEY  AUTO_INCREMENT,
  AssignmentType VARCHAR(100),
  Name 	VARCHAR(100),
  Score INT,
  Letter VARCHAR(100),
  Due_Date VARCHAR(100),
  Unique_Var VARCHAR(100)
);

SELECT * From Gradebook;
SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook where Date(due_date) BETWEEN  CAST('2021-03-01' as Date) and CAST('2021-05-01' as Date) order by Date(due_date);

SELECT assignmentType, name, score, letter, due_date, Unique_Var FROM Gradebook WHERE mod(score, 2) = 0;
